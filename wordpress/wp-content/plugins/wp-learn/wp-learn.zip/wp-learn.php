<?php

/* 
Plugin Name: Learn Wordpress
Description: This is my first plugin! It makes a new admin menu link!
Author: Your Name

 */

require_once plugin_dir_path(__FILE__).'includes/hook-action.php';
require_once plugin_dir_path(__FILE__).'includes/hook-filter.php';
require_once plugin_dir_path(__FILE__).'includes/option-api.php';
require_once plugin_dir_path(__FILE__).'includes/admin-menu.php';
require_once plugin_dir_path(__FILE__).'includes/my-meta-boxes.php';
require_once plugin_dir_path(__FILE__).'includes/custom-post-type.php';
require_once plugin_dir_path(__FILE__).'includes/custom-taxonomy.php';


