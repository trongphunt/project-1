<?php ?>
<!DOCTYPE html>
<html>

    <head>
        <?php wp_head();?>
        
    </head>
    <body <?php get_body_class();?>>
